// Wait for the DOM to be fully loaded before running the script
document.addEventListener("DOMContentLoaded", () => {

    // Get references to all the HTML elements we need
    const loginView = document.getElementById("login-view");
    const signedInView = document.getElementById("signed-in-view");
    
    const loginForm = document.getElementById("login-form");
    const usernameInput = document.getElementById("username-input");
    const passwordInput = document.getElementById("password-input");
    
    const logoutButton = document.getElementById("logout-button");
    
    const signedInUsername = document.getElementById("signed-in-username");
    const signedOutMessage = document.getElementById("signed-out-message");
    const errorMessage = document.getElementById("error-message");

    // This function handles the login form submission
    function handleLogin(event) {
        // Prevent the form from actually submitting and reloading the page
        event.preventDefault(); 
        
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        // Check if both fields have values
        if (username !== '' && password !== '') {
            // --- SUCCESSFUL LOGIN ---

            // 1. Update the username in the "signed in" view
            signedInUsername.textContent = username;

            // 2. Hide the login view
            loginView.classList.add("hidden");

            // 3. Show the signed-in view
            signedInView.classList.remove("hidden");

            // 4. Hide any previous messages
            signedOutMessage.classList.add("hidden");
            errorMessage.classList.add("hidden");

        } else {
            // --- FAILED LOGIN (replaces alert) ---

            // 1. Show an error message
            errorMessage.textContent = "Please enter both username and password.";
            errorMessage.classList.remove("hidden");

            // 2. Hide the signed-out message just in case
            signedOutMessage.classList.add("hidden");
        }
    }

    // This function handles the logout button click
    function handleLogout() {
        // --- LOGOUT ---

        // 1. Show the login view
        loginView.classList.remove("hidden");

        // 2. Hide the signed-in view
        signedInView.classList.add("hidden");

        // 3. Show the "You've signed out" message
        signedOutMessage.classList.remove("hidden");

        // 4. Hide any error messages
        errorMessage.classList.add("hidden");

        // 5. Clear the input fields
        usernameInput.value = "";
        passwordInput.value = "";
    }

    // Attach the functions to the correct events
    loginForm.addEventListener("submit", handleLogin);
    logoutButton.addEventListener("click", handleLogout);

});